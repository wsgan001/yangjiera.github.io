package librec.rating;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.HashMultiset;
import com.google.common.collect.Multiset;

import librec.data.DenseMatrix;
import librec.data.MatrixEntry;
import librec.data.SparseMatrix;
import librec.data.SparseVector;
import librec.intf.IterativeRecommender;
import librec.util.FileIO;
/**
 * Case 1 (b): one item belongs to multiple categories, and each user and item has the same user and item bias.
 * 
 * **/
public class MF extends IterativeRecommender{

	private Multiset<Integer> cateDist = HashMultiset.create();
	public MF(SparseMatrix trainMatrix, SparseMatrix testMatrix, int fold) {
		super(trainMatrix, testMatrix, fold);
		// TODO Auto-generated constructor stub
	}
	
	protected void intialModel() throws Exception{
		super.initModel();
		double initial = 0.6;
		P.init(initial);
		Q.init(initial);
	}
	
	/*
	//output hiearchy
	protected void output(){
		for (String user: hierarchy.keySet()) {
			System.out.print(user+"| ");
			System.out.print(hierarchy.get(user).get(0)+"| ");
			System.out.print(hierarchy.get(user).get(1)+"| ");
			System.out.print(hierarchy.get(user).get(2)+"| ");
			System.out.println();
		}
	}
	
	//output the right format of user hierarchy
	protected void outHierarchy() {
		
		String catePath = "D:/datasets/RecSys2016/instagram/user_hierarchy.txt";
		try {
			FileIO.deleteFile(catePath);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<String> catelines = new ArrayList<>();
		
		for (String user : userinfo.keySet()) {
			String line = null;
			for (String country: userinfo.get(user).keySet()) {
				String city = userinfo.get(user).get(country);
				String continent = continentsinfo.get(country);
				line = user+"|"+continent+"|"+country+"|"+city;
				catelines.add(line);
			}
		}
		
		try {
			FileIO.writeList(catePath, catelines, null, true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
	protected void resetHierarchy(){
		
		String catePath = "D:/datasets/RecSys2016/Amazon/item_hierarchy_1.txt";
		try {
			FileIO.deleteFile(catePath);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<String> catelines = new ArrayList<>();
		
		for (String item : hierarchy.keySet()) {
			String city = hierarchy.get(item).get(0);
			String country = hierarchy.get(item).get(1);
			String continent = hierarchy.get(item).get(2);
			String line = item+"|"+continent+"|"+country+"|"+city+"\r";
			catelines.add(line);
		}
		
		try {
			FileIO.writeList(catePath, catelines, null, true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void buildModel() throws Exception{
		
		//output();
		//outHierarchy();
		//resetHierarchy();
		
		for (int iter = 1; iter <= numIters; iter++) {

			loss = 0;	

			for (MatrixEntry me : trainMatrix) {
				int u = me.row();
				int j = me.column();
				double ruj = me.get();

				if (ruj <= 0) continue;
				double pred = predict(u, j, false);
				double euj = pred - ruj;

				loss += euj * euj;

				for (int f = 0; f < numFactors; f++) {
					double puf = P.get(u, f);
					double qjf = Q.get(j, f);
					P.add(u, f,-lRate * ( euj * qjf + regU * puf));
					Q.add(j, f,-lRate * ( euj * puf + regI * qjf));
					loss += regU * puf * puf + regI * qjf * qjf;
				}
			}

			loss *= 0.5;
			if (isConverged(iter)) break;
		}
	}
	
	protected double predict (int u, int j, boolean bond) {

		double pred = DenseMatrix.rowMult(P, u, Q, j);
		return pred;
	}

}
