Dataset Instructions (RecSys2016 File):

We use one dataset as an example for the user side recursive regularization, that is London on Twitter:

(1) london.txt: the user-item rating data;
(2) user_hierarchy.txt: the auxiliary feature hierarchy for users. 


Alogrithm Running Instructions (librec-master-RecSys2016 File):

(1) Download the source code and dataset into your local file;
(2) Unzip the source code and import it into Eclipse as follows:

File -> Import -> General -> Existing Projects into Workspace -> Next -> Select your source code -> Finish;

(3) Configure parameters for the algorithms as follows:

Open the "librec.conf" file under the following path: librec -> src/main/resources -> librec.conf

Set the path of training data as follows, 
For Windows, dataset.ratings.wins = .....
For Linux, dataset.ratings.lins = .....

Set the path of feature hierarchy as follows, 
For Windows, dataset.hierarchy.wins = ....
For Linux, dataset.hierarchy.lins = ....

In order to upload the hiearchy mentioned above, you need to set 
is.hierarchy.add = on; 

Set the value of parameter alpha for ReMF, ReMF.alpha = ....;

If auxiliary user feature hiearchy is available, then set as follows, 
ReMF.side = user; 
If auxiliary item feature hierarchy is available, then set as follows,
ReMF.side = item;

Set the name of recommendation algorithm that you want to run as follows,
Recommender = ReMF; If running other algorithms, change the name. 

Set the test view and early stop as follows:
evaluation.setup = cv -k 5 --test-view all --early-stop RMSE; If you want to get the results for "cold start" view, then change "all" to be "cold-start"


In order to get the ranking results, you need to set: item.ranking = on; If you want to get the rating prediction results, then set it to be "off";

Set the dimension of the latent factors: num.factors = ....
Set the number of iterations: num.max.iter = ....
Set the value of learning rate: learn.rate = ....
Set the value of regularization coefficient: reg.lambda = ....

(4) Run our algorithm as follows:

librec -> src/main/java -> librec.rating -> ReMF.java -> Right click -> Run As -> Run on Serve

(5) Here is the example for the parameter settings on the dataset with the test view being "all":

London (Twitter)
learn.rate = 0.0001; reg.lambda = 0.05;ReMF.alpha = 0.01; num.factors = 10; num.max.iter = 200; is.hierarchy.add = on; ReMF.side = user; 
evaluation.setup = cv -k 5 --test-view all --early-stop RMSE;
MAE = 0.0772; RMSE =0.1114; AUC = 0.7621






 



 





